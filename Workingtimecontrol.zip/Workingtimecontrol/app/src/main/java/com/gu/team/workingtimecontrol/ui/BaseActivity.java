package com.gu.team.workingtimecontrol.ui;

import android.arch.lifecycle.ViewModelProviders;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.gu.team.workingtimecontrol.viewmodels.BaseViewModel;
import com.gu.team.workingtimecontrol.R;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
        BaseViewModel model = ViewModelProviders.of(this).get(BaseViewModel.class);
    }
}
