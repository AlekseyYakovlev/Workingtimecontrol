package com.gu.team.workingtimecontrol.viewmodels;

import android.arch.lifecycle.ViewModel;

public class BaseViewModel extends ViewModel {
}
